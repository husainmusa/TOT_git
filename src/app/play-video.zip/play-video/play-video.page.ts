import { Component, OnInit,HostListener,NgZone ,ViewChild,ElementRef,Inject} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiProvider } from  '../providers/restapis/restapis';
import { Platform, LoadingController, ToastController ,AlertController} from '@ionic/angular';
import { MediaObject, Media } from '@ionic-native/media/ngx';
import { DOCUMENT} from '@angular/common';
import { DatePipe } from '@angular/common';
import {FormControl} from '@angular/forms';
import {AudioProvider} from '../providers/audio/audio';
import {CANPLAY, LOADEDMETADATA, PLAYING, TIMEUPDATE, LOADSTART, RESET} from '../providers/store/store';
import {Store} from '@ngrx/store';
import {CloudProvider} from '../providers/cloud/cloud';
import {pluck, filter, map, distinctUntilChanged} from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { HttpHeaders } from '@angular/common/http';
import { SafepipePipe } from '../safepipe.pipe';


declare var cordova:any;
const appID = environment.appID;
const apiKey = environment.apiKey;
const serviceAPI = environment.serviceAPI;
const applePayMerchantID=environment.applePayMerchantID;
const stripeSecretKey=environment.stripeSecretKey;
const stripePublishableKey=environment.stripePublishableKey;


import {
  FileTransfer,
  FileTransferObject
} from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';

@Component({
  selector: 'app-play-video',
  templateUrl: './play-video.page.html',
  styleUrls: ['./play-video.page.scss'],
})

export class PlayVideoPage implements OnInit {
    scrHeight:any;
    response_data:any;
    hide_content:boolean=true;
    img_thumbnil:boolean=true;

    timer_display:boolean=false;
    overlay:boolean=true;
    overlay2:boolean=false;

    warmup_res_data:any;
    video_first:any;

    id:any;
    type:any;
    counter:any=10;

    set:any='';
    video:any='';
    thumbnail:any='../assets/images/vid_bg.jpg';
    video_title:any='';
    Next_vid_title:any='Finished';
    Next:any=0;
    // previous:any=0;
    index:any=0;
    count_vid_list_length:any=0;

    showWarning:any=0;
    showSpecialNote:any=1;
    specialNote:any='';
    warningNote:any='';

    timestamp_min:any=0;
    timestamp_sec:any=0;
    currentVideoEle:any;
    videoStatus='play';
    url:any;
    tracks:any;
    message: any;
    storageDirectory: any;
    spotifyToken:any;
    refreshToken:any;
    newUrl:any;



  state: any = {};
  currentFile: any = { 'index' : 0,
                       'url': 'https://ia801504.us.archive.org/3/items/EdSheeranPerfectOfficialMusicVideoListenVid.com/Ed_Sheeran_-_Perfect_Official_Music_Video%5BListenVid.com%5D.mp3'
                     }

// Apple song variables
  firstPlaying:any;
  lastPlaying:any;
  playForfirst:any;
  currentSongIndex=0;
  status:any;
  files:any;
  sckippBack=0;
  skippForward=0;



  public timeBegan = null
  public timeStopped:any = null
  public stoppedDuration:any = 0
  public started = null
  public running = false
  public blankTime = "00:00"
  public time = "00:00"

  //@ViewChild('videoPlayer',null) videoPlayer: ElementRef;
  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
      this.scrHeight = window.innerHeight;
      console.log('h',this.scrHeight);
  }
  @Inject(DOCUMENT) document:HTMLElement;

  constructor( private router       : Router,
      			   private route        : ActivatedRoute,
      			   private zone         : NgZone,
      			   public alertCtrl     : AlertController,
      			   public loadingCtrl   : LoadingController,
      			   private elementRef   : ElementRef,
               public audioProvider : AudioProvider,
      			   public  restProvider : RestapiProvider,
               public platform      : Platform,
               private file         : File,
               public cloudProvider : CloudProvider,
               private store        : Store<any>,
               private transfer     : FileTransfer,
               private toastCtrl    : ToastController,
               private media        : Media,
               private datePipe     : DatePipe,
               private SafepipePipe : SafepipePipe,
      			 )
  {
       this.files =[];
       // console.log('tracjks::',this.tracks = this.restProvider.getSpofityTrackDetail());
       this.platform.ready().then(() => {
        if (this.platform.is('ios')) {

          this.storageDirectory = this.file.dataDirectory;
        } else if (this.platform.is('android')) {
          this.storageDirectory = this.file.externalDataDirectory;
        } else {
          this.storageDirectory = this.file.cacheDirectory;
        }
      });

		   this.getScreenSize();
		   this.route.queryParams.subscribe(params => {
		       console.log('params: ', params);
		      if (this.router.getCurrentNavigation().extras.state) {
			         this.id = this.router.getCurrentNavigation().extras.state.warmup_id;
			         this.type = this.router.getCurrentNavigation().extras.state.type;
			         //console.log(this.id,this.type);
		      }
		    });

       this.spotifyToken=localStorage.getItem("spotifyToken");
       this.refreshToken= localStorage.getItem("spotifyRefreshToken")
       const httpSpotifyOptions = {
           headers: new HttpHeaders({
             'Authorization':'Bearer '+this.spotifyToken
           })
        };
   }



   ngOnInit() {
     if(this.tracks){
     console.log('newTrack',this.newUrl='https://open.spotify.com/embed/album/'+this.tracks.items[0].track.album.id);
      this.url='https://api.spotify.com/v1/tracks/0bVp6yZEUrJzOm2agoFYZm?token='+this.spotifyToken+'&refreshtoken='+this.refreshToken;
     console.log('url',this.url);
     }


     let s=this.cloudProvider.getPlayStatus();
     if(s=='0'){
       this.files = this.cloudProvider.getFiles();
       this.cloudProvider.playTrack(this.files[this.currentSongIndex].id);
     }
     if(this.files.length>0){
       this.skippForward=1;
     }

     
  }



  ionViewWillLoad() {
    this.store.select('appState').subscribe((value: any) => {
      this.state = value.media;
    });
  }
    playAppleTrack(){
      let s=this.cloudProvider.getPlayStatus();
      if(s=='0'){
      this.stopAppleTrack();
      this.cloudProvider.playTrack(this.files[this.currentSongIndex].id);
      this.status=1;
      this.cloudProvider.playstatus('1');
    }else{
      this.resume();
    }
    }
    pauseAppleTrack(){
      this.cloudProvider.pauseTrack();
      this.status=0;
    }
    stopAppleTrack(){
      this.cloudProvider.stopTrack();
    }
    nextAppleTrack(){
      if(this.currentSongIndex<=this.files.length){
        this.currentSongIndex++;
        this.playAppleTrack();
        this.sckippBack=1;
      }else{
        this.currentSongIndex=0;
        this.playAppleTrack();
        this.sckippBack=0;
        this.skippForward=0;
      }
    }
    previousAppleTrack(){
      if(this.currentSongIndex>=0){
        this.currentSongIndex--;
        this.playAppleTrack();
      }else{
        this.currentSongIndex=0;
        this.playAppleTrack();
        this.sckippBack=0;
      }
    }
    resume(){
      this.cloudProvider.resumeTrack();
      this.status=1;
      this.playCurrentVideo();
    }


loadWorkoutVideo(){
  this.restProvider.showLoader();
  this.restProvider.api_method('get','get_workout_vids_detail/'+this.id,null,null).subscribe((data)=>{
     this.restProvider.dismissLoader();
     console.log('get_workout_vids_detail/',data);
     if(data['status']=='success'){
       this.count_vid_list_length=data['data'].length;
       if(data['data'].length > 0){
           this.warmup_res_data=data['data'];
           this.index=0;
           this.thumbnail=data['thumbnail'] ? data['thumbnail'] : '../assets/images/vid_bg.jpg';
           this.setVideo();//
           //this.video_first=data['data']['0'];

         //  this.set=this.video_first.set;
         //  this.video=this.video_first.video;
         //  this.thumbnail=this.video_first.thumbnail;
           //this.video_title=this.video_first.video_title;

           this.showWarning  = data['show_waring_note'] ? data['show_waring_note'] : 0;
           this.showSpecialNote  =data['show_special_note'] ? data['show_special_note'] : 1;
           this.specialNote  = data['special_note'] ? data['special_note'] : '';
           this.warningNote  = data['warning_note'] ? data['warning_note'] : '';

         //  if(data['data']['1']){
           //  this.Next_vid_title=data['data']['1']['video_title'];
         //  }else{
             //this.Next_vid_title='Finished';
             // this.previous=0;
         //  }

         //  console.log('first_vid',this.video_first)
         //  console.log('warmup_res_data',this.warmup_res_data);
       }
     }
     console.log('call 1::::');
 },error=>{
     console.log('error', error);
     this.restProvider.dismissLoader();
 });
}
ionViewWillEnter(){
  this.loadWorkoutVideo();
  console.log("tacks",JSON.stringify(this.files));
  let s=this.cloudProvider.getPlayStatus();
  if(s=='0'){
  this.cloudProvider.playTrack(this.files[this.currentSongIndex].id);
  }
}

async workoutFinished(timeStamp) {
  let me=this;
  const alert = await this.alertCtrl.create({
    header: 'Nice Work',
    //subHeader: 'You have finished this workout',
    cssClass: 'secondary',
    message: '<h1>'+timeStamp+'</h1><p>You have finished this workout</p>',
		buttons: [
		{
		  text: 'Continue Workout',
      role: 'cancel',
		  handler:  () => {
		    me.close_vid();
		  }
		}]
	});
	await alert.present();
}
swipe_vid(arg){
  let me=this;
  let timeStamp=this.time;
  if(arg=='next'){
    this.index++;
  }else{
    this.index--;
  }

  if(this.index>=this.count_vid_list_length){
      console.log('FINISH this.index',this.index,'::count_vid_list_length::',this.count_vid_list_length);
      console.log('time::',timeStamp);
      me.stopClock();
      me.stopAllVideo(function(r){
        me.workoutFinished(timeStamp);
        console.log('call 2::::');
      });
  }else{
    if((this.index > this.count_vid_list_length-1) || this.index < 0 ){
      this.index=0;
    }
    this.setVideo();//
  }

}
stopAllVideo(callback){
  console.log('call 3::::');
  let me=this;
  let workoutVideos=me.warmup_res_data;
  let checkOneByOne=function(){
    if(workoutVideos.length>0){
      let item=workoutVideos.pop();
      if(item){
        let oldVideoEle = <HTMLVideoElement> document.getElementById(item['id']);
        if(oldVideoEle){ oldVideoEle.pause(); checkOneByOne();}
      }else{
        checkOneByOne();
      }
    }else{
      callback(true);
    }
  }
  checkOneByOne();
}
setVideo(){
  try{

    this.video_first = this.warmup_res_data[this.index];

    for (let _i = 0; _i < this.count_vid_list_length; _i++) {
       //console.log(this.index,'footer-indicator-',_i);
       if(document.getElementById('footer-indicator-'+_i)){
         document.getElementById('footer-indicator-'+_i).style.background= _i>this.index ? 'var(--ion-color-light)' :'var(--ion-color-primary)'  ;
       }
    }

    if(this.video_first){
      console.log('call 4::::');
      this.set=this.video_first.set;
      this.video=this.video_first.video;
      //this.thumbnail=this.video_first.thumbnail;
      this.video_title=this.video_first.video_title;

      if(this.index < this.count_vid_list_length-1){
        let next=this.warmup_res_data[this.index+1];
        this.Next_vid_title=next.video_title;
      }else{
        this.Next_vid_title='Finished';
      }

      this.playVideo();//this.video
      // this.play()
    }

  }catch(e){
    console.log('setVideo Catch EE ',e);
  }
}
playCurrentVideo(){
  let me=this;
  console.log('call 5::::');
  if(me.currentVideoEle && typeof me.currentVideoEle.play === 'function'){
    me.currentVideoEle.play();
  }
}
pauseCurrentVideo(){
  let me=this;
  if(me.currentVideoEle && typeof me.currentVideoEle.pause === 'function'){
    me.currentVideoEle.pause();
  }
}
playPauseVideo(){
  if(this.videoStatus=='Pause'){
    console.log('pause');
    this.pauseCurrentVideo();
    this.videoStatus='Play';
  }
  else if(this.videoStatus=='Play'){
    console.log('play');
    this.playCurrentVideo();
    this.videoStatus='Pause';
  }
}
playVideo(){

  try{

    let me=this;
    let videoObj =me.warmup_res_data[me.index];
    me.warmup_res_data.forEach((item, index) => {
        if(index!=me.index){
          me.warmup_res_data[index]['isPlaying']=0; // hidden
        }
        let oldVideoEle = <HTMLVideoElement> document.getElementById(item['id']);
        if(oldVideoEle){
          //console.log('is old ended::',oldVideoEle.ended);
          oldVideoEle.pause();
          console.log('call 6::::');
          this.videoStatus='Pause';
        }
    });

    me.warmup_res_data[me.index]['isPlaying']=1;//show

    let currentVideoEle = <HTMLVideoElement> document.getElementById(videoObj['id']);
    //console.log('playVideo currentVideoEle:::',currentVideoEle);

    if(currentVideoEle){
      currentVideoEle.muted=true;
      currentVideoEle.currentTime = 0;
      currentVideoEle.play();
      me.currentVideoEle=currentVideoEle;

      // this.play()
      me.resume();
      this.videoStatus='play';
      setTimeout(function(){
        currentVideoEle.onended = (event) => {
            console.log('calling end video',event);
            setTimeout(function(){me.swipe_vid('next');},100);
            console.log('call 7::::');
        };
      },500);
      me.resume();
    }
  }catch(e){
    console.log('VIDEO TAG Catch EE ',e);
  }

}


playAudio(arg){
try{
  if(arg=='beep'){
			let audio = new Audio();
			audio.src = "../assets/audio/beep.mp3";
			audio.load();
			audio.play();
	}
	if(arg=='beep2'){
			let audio = new Audio();
			audio.src = "../assets/audio/beep_2.mp3";
			audio.load();
      audio.play();

	}
}catch(e){
  console.log('playAudio Catch Erroor::',arg,e);
}


}

startCountdown(){

  var interval = setInterval(() => {
      // console.log(  this.counter);
      this.counter--;
      if(this.counter==5 ){
        this.pauseAppleTrack();
      }
      if(this.counter==4 || this.counter==3 || this.counter==2){
        this.playAudio('beep');
      }
      if(this.counter == 1 ){
        this.playAudio('beep2');
      }
      if(this.counter < 1 ){

        this.resetClock();
        //this.start();
        clearInterval(interval);
        this.timer_display=false;
        // console.log('Ding!');
        this.overlay=false;
        this.overlay2=true;
        this.img_thumbnil=false;
        this.playVideo();//this.video
      };
  }, 1000);
};
stopClock(){
  clearInterval(this.started);
}

resetClock() {
  let me=this;
  me.timestamp_min=0;
  me.timestamp_sec=0;
  me.start();
}
start() {
  let me=this;
  me.started = setInterval(me.startClock.bind(me), 1000);
}
startClock(){
  let me=this;
  let min=me.timestamp_min;
  let sec=me.timestamp_sec+1;
  if(sec>59){
    min=me.timestamp_min+1;
    sec=0;
  }
  me.timestamp_min=min;
  me.timestamp_sec=sec;
  me.time = me.zeroPrefix(min, 2) + ":" + me.zeroPrefix(sec, 2);
}

zeroPrefix(num, digit) {
  let zero = '';
  for(let i = 0; i < digit; i++) {
    zero += '0';
  }
  return (zero + num).slice(-digit);
}

confirmationBox__() {
  let me=this;
  me.stopClock();
  setTimeout(function(){
    console.log('calling start');
    me.start();
  },3000);
}
async confirmationBox() {
  let me=this;
  me.stopClock();
  me.pauseCurrentVideo();

	const alert = await this.alertCtrl.create({
	header: 'Quit Workout?',
	message: 'Do you realy want to quit your workout.',
		buttons: [
		{
		  text: 'Continue Workout',
		  role: 'cancel',
		  handler: () => {
		    console.log('Confirm Cancel');
        me.playCurrentVideo();
        me.start();
		  }
		},
		{
		  text: 'Quit',
		  cssClass: 'alert-danger',
		  handler:  () => {
		    this.quitWorkoutVideo();
		  }
		}]
	});
	await alert.present();
}
quitWorkoutVideo(){
  let me=this;
  let timeStamp=this.time;
  setTimeout(function(){me.workoutFinished(timeStamp);},200);
  //me.close_vid();
}
close_vid(){
  this.stopClock();
  this.router.navigate(['/tabs/tab2'] );
  return;

  console.log(this.id,this.type);
  if(this.type=='Workout'){
      this.restProvider.api_method('get','get_workout_detail/'+this.id,null,null).subscribe((data)=>{
        console.log('close_vid :: get_workout_detail/::',data);
        if(data['status']==='success'){

          this.response_data=data['workout'];
          this.restProvider.present_Modal(this.response_data,'Workout',null);
          this.zone.run(() => {
            this.router.navigate(['/tabs/tab2'] );
          });

        }else{

        }
      },error=>{
          console.log('error', error);
      });
  }else{
    this.router.navigate(['/tabs/tab2'] );
  }

}

start_vid(){
	this.hide_content=false;
	this.timer_display=true;
	this.startCountdown();
}




}
